export type AstonNavigationBarProps = {
    title: string;
    showBackButton: boolean;
    goBack: () => void;
};
export declare const AstonNavigationBar: ({ title, showBackButton, goBack }: AstonNavigationBarProps) => import("react/jsx-runtime").JSX.Element;
type ProgressBarAnimatedProps = {
    progress: number;
};
export declare function ProgressBarAnimated({ progress }: ProgressBarAnimatedProps): import("react/jsx-runtime").JSX.Element;
export {};
declare const SkeletonShimmer: ({ width, height, borderRadius }: {
    width: any;
    height: any;
    borderRadius?: number | undefined;
}) => import("react/jsx-runtime").JSX.Element;
export default SkeletonShimmer;
import { type TextProps } from 'react-native';
import { Color } from '../theme/Theme';
export type TextType = 'heading' | 'headingMedium' | 'headingStrong' | 'body' | 'bodyMedium' | 'bodyStrong' | 'navBar';
export type ThemedTextProps = TextProps & {
    type?: TextType;
    color?: Color;
};
export declare function ThemedText({ style, type, color, ...rest }: ThemedTextProps): import("react/jsx-runtime").JSX.Element;
import React from 'react';
export type UnifiedVideoPlayerRef = {
    pause: () => void;
    play?: () => void;
    seek?: (time: number) => void;
};
type Props = {
    source: string;
    onDuration?: (duration: number) => void;
    onProgress?: (currentTime: number) => void;
    onError?: (err: any) => void;
    autoPauseOnBlur?: boolean;
};
export declare const UnifiedVideoPlayer: React.ForwardRefExoticComponent<Props & React.RefAttributes<UnifiedVideoPlayerRef>>;
export {};
import React from 'react';
export declare const VideoWeb: React.ForwardRefExoticComponent<Omit<any, "ref"> & React.RefAttributes<unknown>>;
import { type PropsWithChildren } from 'react';
export declare function useSession(): {
    setSession: (session: string) => void;
    session?: string | null;
    integratorUserId: string | null;
    isLoading: boolean;
    customNavigation: boolean;
    onExit?: () => void;
};
export type SessionProviderProps = PropsWithChildren & {
    token?: string | null;
    integratorUserId: string | null;
    customNavigation: boolean;
    onExit?: () => void;
};
export declare const SessionProvider: ({ integratorUserId, customNavigation, onExit, children }: SessionProviderProps) => import("react/jsx-runtime").JSX.Element;
import { type PropsWithChildren } from 'react';
export type FeedbackProviderProps = PropsWithChildren & {};
export declare const FeedbackProvider: ({ children }: FeedbackProviderProps) => import("react/jsx-runtime").JSX.Element;
export declare const ToastProvider: () => import("react/jsx-runtime").JSX.Element;
export declare const getIconByAssetName: (assetName: string) => string | undefined;
export declare const getIconByType: (type: string) => string | undefined;
export declare enum AssetName {
    TRUE = "true",
    FALSE = "false",
    STAR_PURPLE = "star-purple",
    LESSON = "lesson",
    CONGRATS_HEADER = "congrats-header",
    ERROR = "error",
    COIN = "coin",
    ASTON_LOGO = "aston-logo",
    TROPHY = "trophy"
}
type AssetType = string | undefined;
export declare const useAsset: (resourceName: AssetName) => AssetType;
export {};
import { Color } from "../theme/Theme";
export declare const useColor: (color: Color) => string;
export declare const useCongratsAnimations: (isLoading: boolean, score?: number, totalQuestions?: number) => {
    headerAnimatedStyle: {
        opacity: number;
        transform: ({
            scale: number;
            translateY?: undefined;
        } | {
            translateY: number;
            scale?: undefined;
        })[];
    };
    starTopAnimatedStyle: {
        opacity: number;
        transform: ({
            scale: number;
            rotate?: undefined;
        } | {
            rotate: string;
            scale?: undefined;
        })[];
    };
    cardAnimatedStyle: {
        opacity: number;
        transform: ({
            translateY: number;
            scale?: undefined;
        } | {
            scale: number;
            translateY?: undefined;
        })[];
    };
    starBottomAnimatedStyle: {
        opacity: number;
        transform: ({
            scale: number;
            rotate?: undefined;
        } | {
            rotate: string;
            scale?: undefined;
        })[];
    };
    rewardAnimatedStyle: {
        opacity: number;
        transform: {
            scale: number;
        }[];
    };
    buttonAnimatedStyle: {
        opacity: number;
        transform: {
            translateY: number;
        }[];
    };
};
export type ConstantKey = 'API_BASE_URL' | 'APP_VERSION';
export type Constants = {
    API_BASE_URL: string;
    APP_VERSION: string;
};
export declare const useConstants: (key: ConstantKey) => string;
type EventType = "NPS" | "NICKNAME" | "LESSON_COMPLETED" | "FEEDBACK_INPUT" | "NICKNAME";
export declare const useEmitter: () => {
    subscribe: (type: EventType, callback: (context: Record<string, any>) => Promise<void> | void) => void;
    fire: (type: EventType, context: Record<string, any>) => Promise<void>;
};
export declare const cleanListeners: () => void;
export {};
export type Intensity = 'light' | 'medium' | 'heavy';
export type FeedbackType = 'success' | 'error' | 'impact';
export declare const useHapticFeedback: () => {
    readonly triggerFeedback: (type: FeedbackType) => void;
    readonly triggerSuccess: () => void;
    readonly triggerError: () => void;
    readonly triggerImpact: () => void;
};
export declare const useNavigationBar: () => (({ title, showBackButton, goBack }: import("../components/NavigationBar").AstonNavigationBarProps) => import("react/jsx-runtime").JSX.Element) | import("react").FC<import("../components/NavigationBar").AstonNavigationBarProps>;
interface UseQuizAnimationsProps {
    isEntering: boolean;
    questionId: string;
}
export declare const useQuizAnimations: ({ isEntering, questionId, }: UseQuizAnimationsProps) => {
    containerAnimatedStyle: {
        transform: {
            translateX: number;
        }[];
        opacity: number;
    };
    answersAnimatedStyle: {
        transform: ({
            translateX: number;
            scale?: undefined;
        } | {
            scale: number;
            translateX?: undefined;
        })[];
    };
    animateFeedback: (correct: boolean) => void;
    animateOut: (cb?: () => void) => void;
    stopFeedback: () => void;
    isAnimating: import("react-native-reanimated").SharedValue<boolean>;
};
export {};
import { APIRequest } from "../services/RestClient";
export declare function useRequest(): {
    request: <T>(apiRequest: APIRequest) => Promise<T | null>;
    isLoading: boolean;
};
import { AstonRouter } from "../models/Router";
export declare const useRouter: () => AstonRouter;
export declare const useSDUI: () => {
    sduiResolver: {
        resolve: (components: import("../models/SDUI").SDUIComponent[]) => React.JSX.Element;
    };
    sduiActionHandler: {
        addHandler: (handler: import("../sdui/handler").SDUIHandler) => void;
        handle: (type: string, data: any) => Promise<void>;
    };
};
interface UseSimpleAnimationsProps {
    animationDuration?: number;
}
export declare const useSimpleAnimations: ({ animationDuration, }?: UseSimpleAnimationsProps) => {
    animatedStyle: {
        opacity: number;
        transform: {
            scale: number;
        }[];
    };
    animateIn: () => void;
    animateOut: () => void;
    resetAnimations: () => void;
};
export {};
import { ThemeConfig } from "../theme/Theme";
export declare const useTheme: () => ThemeConfig;
import { Event } from "../models/Event";
import { Session } from "../models/Auth";
export declare const useTracking: () => (event: Event, session?: Session) => Promise<void>;
export declare const cleanTracking: () => void;
export type Session = string | null | undefined;
export type LoginResponse = {
    token: Session;
    experienceConfig?: {
        showOnboarding: boolean;
    };
};
export declare class RequestError extends Error {
    type: number;
    message: string;
    data?: any;
    constructor(type: number, message: string, data?: any, ...params: any[]);
}
export type EventType = "CTA Tapped" | "Screen Loaded" | "SDK Started" | "SDK Closed" | "Modal Shown" | "Modal Dismissed" | "Modal Completed" | "SDK Bridge Invoked";
export type Event = {
    eventName: EventType;
    properties: any;
};
export type CheckFeedbackResponse = {
    ruleId: string;
    type: string;
    context: Record<string, any>;
    question: string;
    options: string[];
};
export type FeedbackEvent = {
    type: string;
    context: Record<string, any>;
};
export type Lesson = {
    id: string;
    title: string;
    thumbnail: string;
    description: string;
    ranking: number;
    category: string;
    questions: Question[];
    video?: string;
};
export type Question = {
    id: string;
    question: string;
    options: string[];
    correctOption: number;
    explanation?: string;
    hint?: string;
};
export type OnboardingQuestion = {
    question: string;
    options: string[];
};
import { QueryParam } from "../services/RestClient";
export type AstonStackParamList = {
    Loading: {
        clientName?: string;
    };
    Education: undefined;
    Lesson: {
        lessonId: string;
    };
    Quiz: {
        lesson?: string;
    };
    Congrats: {
        lessonId: string;
        responsesRaw?: string;
    };
    Onboarding: undefined;
    Error: undefined;
};
declare const validPaths: readonly ["/education/dashboard", "/education/lesson", "/education/quiz", "/education/congrats", "/education/onboarding", "/error"];
type Path = typeof validPaths[number];
type ScreenRoute = {
    name: keyof AstonStackParamList;
    params?: Record<string, string>;
};
export declare const getScreenRoute: (deeplink: AstonDeeplink) => ScreenRoute;
export type AstonDeeplink = {
    path: Path;
    params?: QueryParam[];
};
export type AstonRouter = {
    canGoBack: () => boolean;
    goBack: () => void;
    push: (deeplink: AstonDeeplink) => void;
    redirect: (deeplink: AstonDeeplink) => void;
    dismissTo: (targetScreen: keyof AstonStackParamList) => void;
    pushFromBase: (baseScreen: keyof AstonStackParamList, target: AstonDeeplink) => void;
};
export declare const createDeeplink: (deeplink: string) => AstonDeeplink;
export {};
export type SDUIComponent = {
    id: string;
    type: string;
    properties: SDUIProperties;
    children: SDUIComponent[];
};
type SDUIProperties = any & {
    actions: SDUIAction[];
};
type SDUIAction = {
    type: string;
    data: any;
};
export {};
import { AstonSDKRef } from "../AstonSDK";
export type AstonNavigatorProps = {
    integratorUserId: string;
    customNavigation: boolean;
    onExit?: () => void;
};
export declare const AstonNavigator: import("react").ForwardRefExoticComponent<AstonNavigatorProps & import("react").RefAttributes<AstonSDKRef>>;
export declare const BffEducationScreen: () => import("react/jsx-runtime").JSX.Element;
type CongratsScreenProps = {
    lessonId: string;
    responsesRaw?: string;
};
export default function CongratsScreen({ lessonId, responsesRaw }: CongratsScreenProps): import("react/jsx-runtime").JSX.Element;
export {};
export default function ErrorScreen(): import("react/jsx-runtime").JSX.Element;
type EducationLessonProps = {
    lessonId: string;
};
export default function LessonScreen({ lessonId }: EducationLessonProps): import("react/jsx-runtime").JSX.Element;
export {};
interface LoadingScreenProps {
    clientName?: string;
}
export default function LoadingScreen({ clientName }: LoadingScreenProps): import("react/jsx-runtime").JSX.Element;
export {};
export declare const OnboardingScreen: () => import("react/jsx-runtime").JSX.Element;
type QuizScreenProps = {
    lessonRaw: string;
};
export default function QuizScreen({ lessonRaw }: QuizScreenProps): import("react/jsx-runtime").JSX.Element;
export {};
import { AstonRouter } from "../models/Router";
export type SDUIHandler = {
    [key: string]: (action: any) => Promise<void>;
};
export declare const sduiHandler: (router: AstonRouter) => {
    addHandler: (handler: SDUIHandler) => void;
    handle: (type: string, data: any) => Promise<void>;
};
export declare const cleanCustomHandlers: () => void;
import { SDUIComponent } from "../models/SDUI";
import React from "react";
export declare const resolve: (components: SDUIComponent[]) => React.JSX.Element;
import { APIRequest } from './RestClient';
export declare const integratorLoginRequest: (integratorUserId: string) => APIRequest;
import { APIRequest } from './RestClient';
export declare const bffRequestFor: (key: string) => APIRequest;
import { APIRequest } from './RestClient';
export declare const fetchLessonRequest: (lessonId: string) => APIRequest;
export declare const startLessonRequest: (lessonId: string) => APIRequest;
export declare const completeLessonRequest: (lessonId: string, answers: any[]) => APIRequest;
import { APIRequest } from './RestClient';
export declare const checkFeedbackRequest: (type: any, context?: {}) => APIRequest;
export declare const submitFeedbackRequest: (ruleId: string, type: string, context: Record<string, any>, response?: string, dismissed?: boolean) => APIRequest;
import { APIRequest } from './RestClient';
export declare const getOnboardingRequest: () => APIRequest;
export declare const completeOnboardingRequest: (answers: any[]) => APIRequest;
import { Session } from "../models/Auth";
export type QueryParam = {
    key: string;
    value: string;
};
export type APIRequest = {
    path: string;
    method: 'POST' | 'PUT' | 'GET' | 'DELETE' | 'PATCH';
    body?: any;
    queryParams?: QueryParam[];
    isAuthenticated: boolean;
    session?: Session;
};
declare function request<T>(model: APIRequest, session?: Session): Promise<T | null>;
export declare const restClient: {
    request: typeof request;
};
export {};
import { APIRequest } from './RestClient';
export declare const trackRequest: (eventName: string, properties: any) => APIRequest;
import { TextStyle, ViewStyle } from "react-native";
export type Color = 'primary' | 'background' | 'textPrimary' | 'positive' | 'negative' | 'contrast' | 'textColorForPrimaryBg';
export type ThemeColors = {
    primary: string;
    background: string;
    textPrimary: string;
    positive: string;
    negative: string;
    contrast: string;
    textColorForPrimaryBg: string;
};
export type ThemeConfig = {
    colors: ThemeColors;
    textStyles: {
        heading: TextStyle;
        headingMedium: TextStyle;
        headingStrong: TextStyle;
        body: TextStyle;
        bodyMedium: TextStyle;
        bodyStrong: TextStyle;
    };
    navBar: {
        navBarTextStyle: TextStyle;
        navBarColor: string;
    };
    buttonStyle: {
        primaryTextStyle: TextStyle;
        secondaryTextStyle: TextStyle;
        primary: ViewStyle;
        secondary: ViewStyle;
        style: ViewStyle;
    };
    cardStyles: ViewStyle;
};
export declare const defaultTheme: ThemeConfig;
import { AstonNavigationBarProps } from "./components/NavigationBar";
import { ThemeConfig } from "./theme/Theme";
export type AstonSDKRef = {
    goBack: () => void;
};
export type AstonConfiguration = {
    apiKey: string;
    theme?: ThemeConfig;
    environment: string;
    NavigationBar?: React.FC<AstonNavigationBarProps>;
} | null;
export declare const AstonSDK: {
    init: (configuration: AstonConfiguration) => void;
};
export declare const getAstonConfig: () => NonNullable<AstonConfiguration>;
export { AstonNavigator } from "./navigation/AstonNavigator";
export { AstonSDK, AstonConfiguration } from "./AstonSDK";
export { ThemeConfig } from "./theme/Theme";
export { AstonNavigationBarProps } from "./components/NavigationBar";
